"""
Database and folder extractor for Nia Local Sync CLI.

Extracts text content from SQLite databases and folders,
converting them into virtual "files" for indexing.

Supported types:
- iMessage (~/Library/Messages/chat.db)
- Safari History (~/Library/Safari/History.db)
- Chrome/Brave/Edge History
- Firefox History (places.sqlite)
- Telegram (JSON export)
- Regular folders
"""
import os
import re
import json
import sqlite3
import zipfile
import logging
from datetime import datetime, timezone
from typing import Any
from pathlib import Path

logger = logging.getLogger(__name__)

# =============================================================================
# EXCLUSION PATTERNS - Synced with backend/utils/exclusion_patterns.py
# =============================================================================

# Directories to skip entirely (prevents os.walk from descending)
SKIP_DIRS = {
    # VCS
    ".git", ".svn", ".hg", ".bzr",
    # Node/JS
    "node_modules", ".npm", ".pnpm-store", ".yarn", "bower_components",
    ".next", ".nuxt", ".output", ".svelte-kit", ".parcel-cache", ".cache", ".turbo",
    # Python
    "__pycache__", "venv", ".venv", "env", ".tox", ".nox",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".hypothesis", "htmlcov", ".Python",
    # JVM
    "target", ".gradle", ".m2",
    # Rust
    "target",
    # Go
    "vendor",
    # Ruby
    ".bundle",
    # .NET
    "bin", "obj", "packages",
    # iOS/macOS
    "DerivedData", "Pods", ".build",
    # Build outputs
    "dist", "build", "out", "output", "release", "debug", "coverage", ".nyc_output",
    # IDE
    ".idea", ".vscode", ".atom",
    # OS
    ".Spotlight-V100", ".Trashes",
    # Misc
    ".terraform", ".vagrant", ".docker", ".kube",
    "logs", "log", "tmp", "temp",
    ".aws", ".ssh",
}

# File extensions to skip (from backend exclusion_patterns.py)
SKIP_EXTENSIONS = {
    # Security - keys/certs/GPG
    ".pem", ".key", ".p12", ".pfx", ".crt", ".cer", ".asc",
    # Python compiled
    ".pyc", ".pyo", ".pyd", ".egg",
    # JVM
    ".class", ".jar", ".war", ".ear",
    # .NET
    ".exe", ".pdb", ".nupkg",
    # Compiled binaries
    ".so", ".dylib", ".dll", ".o", ".obj", ".a", ".lib", ".wasm",
    # Databases
    ".sqlite", ".sqlite3", ".db", ".sql",
    # Images
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".webp", ".bmp", ".tiff", ".tif",
    ".psd", ".ai", ".sketch", ".fig",
    # Videos
    ".mp4", ".avi", ".mov", ".wmv", ".webm", ".mkv", ".flv",
    # Audio
    ".mp3", ".wav", ".ogg", ".flac", ".aac", ".m4a",
    # Documents
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    # Archives
    ".zip", ".tar", ".gz", ".tgz", ".rar", ".7z", ".bz2", ".xz",
    # Fonts
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    # Logs/temp
    ".log", ".tmp", ".temp", ".bak", ".backup", ".old", ".swp", ".swo",
    # Coverage
    ".lcov",
    # IDE
    ".code-workspace",
}

# Specific filenames to skip (from backend exclusion_patterns.py)
SKIP_FILES = {
    # Lock files
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb",
    "poetry.lock", "Pipfile.lock", "Gemfile.lock", "composer.lock",
    "Cargo.lock", "gradle.lockfile", "Package.resolved",
    # OS files
    ".DS_Store", "Thumbs.db", "desktop.ini", "ehthumbs.db",
    # Security - credentials
    ".env", ".envrc", ".npmrc", ".pypirc", ".netrc", ".htpasswd",
    # Logs
    "npm-debug.log", "yarn-debug.log", "yarn-error.log", ".pnpm-debug.log",
    "pip-log.txt",
    # IDE
    ".project", ".classpath",
    # Python
    ".coverage",
}

# Patterns that match anywhere in the path (for files like id_rsa, credentials.json)
SKIP_PATH_PATTERNS = {
    "credentials", "secrets", ".secret", ".secrets",
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
}

# Filename patterns to skip (case-insensitive substring match)
SKIP_FILENAME_PATTERNS = {
    "openpgp", "pgp_key", "gpg_key", "pubkey", "privkey",
    "public_key", "private_key", "signing_key",
    "0x",  # Common GPG key ID prefix like OpenPGP_0xF6E60454C
}

# Known extensionless filenames that ARE valid source files
ALLOWED_EXTENSIONLESS_FILES = {
    "makefile", "dockerfile", "vagrantfile", "procfile", "gemfile",
    "rakefile", "guardfile", "brewfile", "berksfile", "thorfile",
    "capfile", "podfile", "fastfile", "appfile", "matchfile",
    "snapfile", "scanfile", "gymfile", "deliverfile", "pluginfile",
    "cmakelists.txt",  # has extension but sometimes referenced without
    "justfile", "taskfile", "earthfile",
    "readme", "changelog", "license", "licence", "authors",
    "contributing", "copying", "todo", "news", "history",
}


def _get_custom_ignore_sets() -> tuple[set[str], set[str], set[str], set[str]]:
    try:
        from config import get_ignore_patterns
    except Exception:
        return set(), set(), set(), set()

    patterns = get_ignore_patterns()
    custom_dirs = {p for p in patterns.get("dirs", []) if p}
    custom_files = {p for p in patterns.get("files", []) if p}
    custom_exts = set()
    for ext in patterns.get("extensions", []) or []:
        if not ext:
            continue
        normalized = ext.strip().lower()
        if not normalized.startswith("."):
            normalized = f".{normalized}"
        custom_exts.add(normalized)
    custom_path_patterns = {p.lower() for p in patterns.get("path_patterns", []) if p}
    return custom_dirs, custom_files, custom_exts, custom_path_patterns

def _is_likely_binary(content: bytes, sample_size: int = 8192) -> bool:
    """Check if content appears to be binary (null bytes or high non-printable ratio)."""
    sample = content[:sample_size]
    if not sample:
        return False
    if b'\x00' in sample:
        return True
    # High ratio of non-printable, non-whitespace chars suggests binary
    non_text = sum(1 for b in sample if b < 8 or (14 <= b < 32))
    return non_text / len(sample) > 0.10


# Type identifiers
TYPE_IMESSAGE = "imessage"
TYPE_SAFARI_HISTORY = "safari_history"
TYPE_CHROME_HISTORY = "chrome_history"
TYPE_FIREFOX_HISTORY = "firefox_history"
TYPE_TELEGRAM = "telegram"
TYPE_FOLDER = "folder"
TYPE_GENERIC_DB = "generic"

# Limits
MAX_ROWS = 100_000
MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024  # 10MB per file


def _connect_sqlite_readonly(db_path: str) -> sqlite3.Connection:
    """Open SQLite database in read-only mode to avoid lock issues."""
    return sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=1)


def _normalize_phone(phone: str) -> str:
    """Strip non-digits for phone number matching (same as Vaulty)."""
    return re.sub(r"\D", "", phone)


def _build_contact_lookup() -> dict[str, str]:
    """Build a phone/email → display name lookup from macOS AddressBook.

    Reads ~/Library/Application Support/AddressBook/Sources/*/AddressBook-v22.abcddb
    and returns a dict mapping normalized phone numbers and lowercased emails to
    full names (e.g. "Lin Chen").

    Returns empty dict if AddressBook is not accessible.
    """
    lookup: dict[str, str] = {}
    address_book_dir = os.path.join(
        os.path.expanduser("~"),
        "Library", "Application Support", "AddressBook", "Sources",
    )

    if not os.path.isdir(address_book_dir):
        logger.debug("AddressBook directory not found, skipping contact lookup")
        return lookup

    # Find all AddressBook databases across sources
    db_paths = []
    try:
        for source_dir in os.listdir(address_book_dir):
            db_path = os.path.join(address_book_dir, source_dir, "AddressBook-v22.abcddb")
            if os.path.isfile(db_path):
                db_paths.append(db_path)
    except PermissionError:
        logger.warning("Permission denied reading AddressBook directory")
        return lookup

    for db_path in db_paths:
        try:
            conn = _connect_sqlite_readonly(db_path)
            try:
                conn.row_factory = sqlite3.Row
                cur = conn.cursor()

                # Get all people with names
                people = cur.execute("""
                    SELECT Z_PK as pk, ZFIRSTNAME as first_name, ZLASTNAME as last_name,
                           ZORGANIZATION as organization
                    FROM ZABCDRECORD
                    WHERE ZFIRSTNAME IS NOT NULL OR ZLASTNAME IS NOT NULL
                """).fetchall()

                for person in people:
                    name_parts = [person["first_name"], person["last_name"]]
                    name = " ".join(p for p in name_parts if p).strip()
                    if not name:
                        name = person["organization"] or ""
                    if not name:
                        continue

                    pk = person["pk"]

                    # Map phone numbers
                    phones = cur.execute(
                        "SELECT ZFULLNUMBER as phone FROM ZABCDPHONENUMBER WHERE ZOWNER = ?",
                        (pk,),
                    ).fetchall()
                    for row in phones:
                        if row["phone"]:
                            normalized = _normalize_phone(row["phone"])
                            if normalized:
                                lookup[normalized] = name

                    # Map emails
                    emails = cur.execute(
                        "SELECT ZADDRESSNORMALIZED as email FROM ZABCDEMAILADDRESS WHERE ZOWNER = ?",
                        (pk,),
                    ).fetchall()
                    for row in emails:
                        if row["email"]:
                            lookup[row["email"].lower().strip()] = name

                logger.info(f"Loaded {len(lookup)} contact entries from AddressBook")
            finally:
                conn.close()

        except Exception as e:
            logger.warning(f"Error reading AddressBook at {db_path}: {e}")

    return lookup


def _resolve_contact_name(contact_id: str, contact_lookup: dict[str, str]) -> str:
    """Resolve a phone/email identifier to a human name using contact lookup.

    Returns the resolved name if found, otherwise the original identifier.
    """
    if not contact_id or not contact_lookup:
        return contact_id or "Unknown"

    # Email lookup
    if "@" in contact_id:
        name = contact_lookup.get(contact_id.lower().strip())
        if name:
            return name
        return contact_id

    # Phone lookup (normalize to digits)
    normalized = _normalize_phone(contact_id)
    if normalized:
        name = contact_lookup.get(normalized)
        if name:
            return name

    return contact_id


def _group_messages_into_conversations(
    files: list[dict[str, Any]],
    window_minutes: int = 30,
) -> list[dict[str, Any]]:
    """Group individual message files into conversation chunks.

    Messages within the same conversation_id that are within `window_minutes` of
    each other are merged into a single multi-message chunk formatted as a
    mini-transcript.  This gives agents conversational context instead of
    isolated single-message hits.

    Returns a new list of file dicts (original messages are replaced).
    """
    from collections import defaultdict

    # Group by conversation_id
    convos: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for f in files:
        cid = f.get("metadata", {}).get("conversation_id", "unknown")
        convos[cid].append(f)

    grouped: list[dict[str, Any]] = []

    for cid, msgs in convos.items():
        # Sort by timestamp within conversation
        def _ts_key(m: dict) -> str:
            return m.get("metadata", {}).get("timestamp") or ""
        msgs.sort(key=_ts_key)

        # Window-based chunking
        current_window: list[dict[str, Any]] = []
        window_start_ts = None

        for msg in msgs:
            ts_str = msg.get("metadata", {}).get("timestamp")
            ts = None
            if ts_str:
                try:
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                except Exception:
                    pass

            # Start new window if gap is too large
            if current_window and ts and window_start_ts:
                gap = (ts - window_start_ts).total_seconds()
                if gap > window_minutes * 60:
                    grouped.append(_build_conversation_chunk(cid, current_window))
                    current_window = []
                    window_start_ts = None

            current_window.append(msg)
            if ts and window_start_ts is None:
                window_start_ts = ts
            if ts:
                window_start_ts = min(window_start_ts, ts) if window_start_ts else ts

        # Flush remaining
        if current_window:
            grouped.append(_build_conversation_chunk(cid, current_window))

    return grouped


def _build_conversation_chunk(
    conversation_id: str,
    messages: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a single conversation chunk from a list of messages."""
    if len(messages) == 1:
        # Single message — return as-is (already formatted)
        return messages[0]

    # Determine participants and date range
    first_meta = messages[0].get("metadata", {})
    last_meta = messages[-1].get("metadata", {})
    contact_name = first_meta.get("contact", "Unknown")
    date_prefix = (first_meta.get("timestamp") or "")[:10] or "unknown"

    # Build transcript
    lines = [f"[Conversation with {contact_name}, {date_prefix}]", ""]
    participants = set()
    for msg in messages:
        content = msg.get("content", "")
        lines.append(content)
        meta = msg.get("metadata", {})
        participants.add(meta.get("contact", "Unknown"))

    transcript = "\n".join(lines)

    # Use first message's path prefix for the grouped chunk
    safe_contact = re.sub(r"[^\w\-_]", "_", str(contact_name))[:50]
    first_row = first_meta.get("row_id", 0)
    last_row = last_meta.get("row_id", 0)
    file_path = f"messages/{safe_contact}/{date_prefix}_conv_{first_row}_{last_row}.txt"

    return {
        "path": file_path,
        "content": transcript,
        "metadata": {
            **first_meta,
            "conversation_id": conversation_id,
            "participants": list(participants),
            "message_count": len(messages),
            "time_range_start": first_meta.get("timestamp"),
            "time_range_end": last_meta.get("timestamp"),
            "is_conversation_chunk": True,
        },
    }


def _extract_text_from_attributed_body(blob: bytes) -> str | None:
    """Extract plain text from NSAttributedString blob (attributedBody column).

    On modern macOS (Ventura+), iMessage stores message text in the
    attributedBody column as a serialized NSAttributedString, not in the
    plain text column.  This function extracts the readable text from the blob.
    """
    if not blob:
        return None

    try:
        # The NSAttributedString blob is a binary plist / NSKeyedArchiver stream.
        # The plain text is stored as a length-prefixed UTF-8 string early in the blob,
        # typically right after the streamtyped header and before attribute dictionaries.
        #
        # Reliable approach: find the text between the header and the first
        # __kIMMessagePartAttributeName marker, then clean it.

        decoded = blob.decode("utf-8", errors="ignore")

        _SKIP_PREFIXES = (
            "streamtyped", "NSMutable", "NSString", "NSSt", "NSObject",
            "NSValue", "NSData", "NSAttributedString", "NSDictionary",
            "NSNumber", "NSArray",
        )

        def _clean_text(t: str) -> str:
            """Strip binary length-prefix bytes that leak into extracted text."""
            import re as _re
            # Strip leading punctuation (1-2 chars) before actual text start
            t = _re.sub(r"^[+\-*/=<>!@#$%^&(){}|\\;:'\",.<>?/~`]{1,2}(?=[A-Za-z\u00C0-\uFFFF])", "", t)
            return t.strip()

        # Strategy 1: Extract text before the IM attribute marker
        marker = "__kIMMessagePartAttributeName"
        idx = decoded.find(marker)
        if idx > 0:
            candidate = decoded[:idx]
            import re as _re
            runs = list(_re.finditer(r"[\x20-\x7E\u00A0-\uFFFF]{3,}", candidate))
            if runs:
                text_runs = [r.group() for r in runs if not any(r.group().startswith(p) for p in _SKIP_PREFIXES)]
                if text_runs:
                    result = _clean_text(max(text_runs, key=len))
                    if result:
                        return result

        # Strategy 2: No marker found — get longest readable fragment
        import re as _re
        fragments = _re.findall(r"[\x20-\x7E\u00A0-\uFFFF]{3,}", decoded)
        text_fragments = [f for f in fragments if not any(f.startswith(p) for p in _SKIP_PREFIXES)]
        if text_fragments:
            return _clean_text(max(text_fragments, key=len))

    except Exception:
        pass

    return None


def detect_source_type(path: str) -> str:
    """
    Auto-detect the type of source based on path and file structure.

    Args:
        path: Path to file or directory

    Returns:
        Type identifier string
    """
    # Check if directory (regular folder or telegram export)
    if os.path.isdir(path):
        if os.path.exists(os.path.join(path, "result.json")):
            return TYPE_TELEGRAM
        return TYPE_FOLDER

    # Check for Telegram JSON export
    if path.endswith(".json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                if "chats" in data and isinstance(data.get("chats"), dict):
                    return TYPE_TELEGRAM
        except Exception:
            pass

    # Check for ZIP (could be Telegram export)
    if zipfile.is_zipfile(path):
        try:
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                if "result.json" in names or any(n.endswith("/result.json") for n in names):
                    return TYPE_TELEGRAM
        except Exception:
            pass

    # Check SQLite databases
    if not os.path.isfile(path):
        return TYPE_FOLDER

    try:
        conn = _connect_sqlite_readonly(path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = {row[0].lower() for row in cursor.fetchall()}
        conn.close()

        # iMessage
        if "message" in tables and "handle" in tables and "chat" in tables:
            return TYPE_IMESSAGE

        # Safari History
        if "history_items" in tables and "history_visits" in tables:
            return TYPE_SAFARI_HISTORY

        # Chrome/Brave/Edge History
        if "urls" in tables and "visits" in tables and "keyword_search_terms" in tables:
            return TYPE_CHROME_HISTORY

        # Firefox History
        if "moz_places" in tables and "moz_historyvisits" in tables:
            return TYPE_FIREFOX_HISTORY

        return TYPE_GENERIC_DB

    except Exception:
        return TYPE_FOLDER


def extract_incremental(
    path: str,
    source_type: str,
    cursor: dict[str, Any] | None = None,
    limit: int = MAX_ROWS,
) -> dict[str, Any]:
    """
    Extract data incrementally from a source.

    Args:
        path: Path to the source
        source_type: Type of source
        cursor: Previous sync cursor (for incremental extraction)
        limit: Maximum items to extract

    Returns:
        Dict with files, new cursor, and stats
    """
    cursor = cursor or {}

    if source_type == TYPE_IMESSAGE:
        return _extract_imessage(path, cursor, limit)
    elif source_type == TYPE_SAFARI_HISTORY:
        return _extract_safari_history(path, cursor, limit)
    elif source_type == TYPE_CHROME_HISTORY:
        return _extract_chrome_history(path, cursor, limit)
    elif source_type == TYPE_FIREFOX_HISTORY:
        return _extract_firefox_history(path, cursor, limit)
    elif source_type == TYPE_TELEGRAM:
        return _extract_telegram(path, cursor, limit)
    elif source_type == TYPE_FOLDER:
        return _extract_folder(path, cursor, limit)
    else:
        return _extract_generic_db(path, cursor, limit)


def _extract_imessage(
    db_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract messages from iMessage chat.db with contact name resolution."""
    files = []
    max_rowid = cursor.get("last_rowid", 0)
    max_timestamp = cursor.get("last_timestamp", 0)
    since_rowid = cursor.get("last_rowid")

    # Build contact lookup for name resolution
    contact_lookup = _build_contact_lookup()

    conn = _connect_sqlite_readonly(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Include attributedBody for modern macOS where text column is often NULL
    where_clauses = ["(m.text IS NOT NULL AND m.text != '' OR m.attributedBody IS NOT NULL)"]
    params = []

    if since_rowid:
        where_clauses.append("m.ROWID > ?")
        params.append(since_rowid)

    params.append(limit)

    query = f"""
        SELECT
            m.ROWID as row_id,
            m.text,
            m.attributedBody,
            m.date,
            m.is_from_me,
            m.service,
            m.thread_originator_guid,
            h.id as contact_id,
            COALESCE(h.uncanonicalized_id, h.id) as contact_display
        FROM message m
        LEFT JOIN handle h ON m.handle_id = h.ROWID
        WHERE {' AND '.join(where_clauses)}
        ORDER BY m.ROWID ASC
        LIMIT ?
    """

    cur.execute(query, params)
    rows = cur.fetchall()

    for row in rows:
        row_id = row["row_id"]
        text = row["text"]
        apple_date = row["date"]
        is_from_me = row["is_from_me"]
        raw_contact = row["contact_display"] or row["contact_id"] or "unknown"
        service = row["service"]
        thread_guid = row["thread_originator_guid"]

        # Fall back to attributedBody if text column is empty (macOS Ventura+)
        if not text or not text.strip():
            attributed_body = row["attributedBody"]
            if attributed_body:
                text = _extract_text_from_attributed_body(attributed_body)

        max_rowid = max(max_rowid, row_id)
        if apple_date:
            max_timestamp = max(max_timestamp, apple_date)

        if not text or len(text.strip()) < 2:
            continue

        # Resolve contact name from AddressBook
        contact_name = _resolve_contact_name(raw_contact, contact_lookup)

        # Convert Apple date to ISO
        time_display = ""
        try:
            if apple_date:
                unix_ts = (apple_date / 1_000_000_000) + 978307200
                dt = datetime.fromtimestamp(unix_ts, tz=timezone.utc)
                timestamp_str = dt.isoformat()
                date_prefix = dt.strftime("%Y-%m-%d")
                time_display = dt.strftime("%H:%M")
            else:
                timestamp_str = None
                date_prefix = "unknown"
        except Exception:
            timestamp_str = None
            date_prefix = "unknown"

        # Conversation-aware content: embed sender name + timestamp into chunk text
        sender_role = "self" if is_from_me else "contact"
        if is_from_me:
            content = f"[You → {contact_name}, {date_prefix} {time_display}] {text}"
        else:
            content = f"[{contact_name} → You, {date_prefix} {time_display}] {text}"

        # Derive conversation_id for retrieval grouping
        conversation_id = thread_guid or raw_contact or "unknown"

        safe_contact = re.sub(r"[^\w\-_]", "_", str(contact_name))[:50]
        direction = "sent" if is_from_me else "received"
        file_path = f"messages/{safe_contact}/{date_prefix}_{row_id}_{direction}.txt"

        files.append({
            "path": file_path,
            "content": content,
            "metadata": {
                "db_type": TYPE_IMESSAGE,
                "source_subtype": "database",
                "row_id": row_id,
                "timestamp": timestamp_str,
                "contact": contact_name,
                "contact_id": raw_contact,
                "conversation_id": conversation_id,
                "sender_role": sender_role,
                "is_from_me": bool(is_from_me),
                "service": service,
                "thread_id": thread_guid,
            },
        })

    conn.close()

    # Group individual messages into conversation chunks for better retrieval
    raw_count = len(files)
    files = _group_messages_into_conversations(files)
    logger.info(
        f"Extracted {raw_count} messages from iMessage → {len(files)} conversation chunks "
        f"(contacts resolved: {len(contact_lookup)} entries)"
    )

    return {
        "files": files,
        "cursor": {"last_rowid": max_rowid, "last_timestamp": max_timestamp},
        "stats": {"extracted": raw_count, "chunks": len(files), "db_type": TYPE_IMESSAGE},
    }


def _extract_safari_history(
    db_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract browsing history from Safari History.db."""
    files = []
    max_visit_time = cursor.get("last_visit_time", 0)
    since_visit_time = cursor.get("last_visit_time")

    conn = _connect_sqlite_readonly(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    where_clauses = ["hv.title IS NOT NULL", "hv.title != ''"]
    params = []

    if since_visit_time:
        where_clauses.append("hv.visit_time > ?")
        params.append(since_visit_time)

    params.append(limit)

    query = f"""
        SELECT
            hi.id,
            hi.url,
            hi.domain_expansion,
            hv.title,
            hv.visit_time
        FROM history_visits hv
        JOIN history_items hi ON hi.id = hv.history_item
        WHERE {' AND '.join(where_clauses)}
        ORDER BY hv.visit_time ASC
        LIMIT ?
    """

    cur.execute(query, params)
    rows = cur.fetchall()

    for row in rows:
        item_id = row["id"]
        url = row["url"] or ""
        domain = row["domain_expansion"] or ""
        title = row["title"] or ""
        visit_time = row["visit_time"]

        max_visit_time = max(max_visit_time, visit_time or 0)

        if not title.strip():
            continue

        try:
            if visit_time:
                unix_ts = visit_time + 978307200
                dt = datetime.fromtimestamp(unix_ts, tz=timezone.utc)
                timestamp_str = dt.isoformat()
                date_prefix = dt.strftime("%Y-%m-%d")
            else:
                timestamp_str = None
                date_prefix = "unknown"
        except Exception:
            timestamp_str = None
            date_prefix = "unknown"

        content = f"{title}\n{url}"
        safe_domain = re.sub(r"[^\w\-_]", "_", domain)[:30] if domain else "other"
        file_path = f"history/{safe_domain}/{date_prefix}_{item_id}.txt"

        files.append({
            "path": file_path,
            "content": content,
            "metadata": {
                "db_type": TYPE_SAFARI_HISTORY,
                "row_id": item_id,
                "timestamp": timestamp_str,
                "url": url,
                "domain": domain,
            },
        })

    conn.close()
    logger.info(f"Extracted {len(files)} history items from Safari")

    return {
        "files": files,
        "cursor": {"last_visit_time": max_visit_time},
        "stats": {"extracted": len(files), "db_type": TYPE_SAFARI_HISTORY},
    }


def _extract_chrome_history(
    db_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract browsing history from Chrome/Brave/Edge."""
    files = []
    max_visit_time = cursor.get("last_visit_time", 0)
    since_visit_time = cursor.get("last_visit_time")

    conn = _connect_sqlite_readonly(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    where_clauses = ["u.title IS NOT NULL", "u.title != ''"]
    params = []

    if since_visit_time:
        where_clauses.append("v.visit_time > ?")
        params.append(since_visit_time)

    params.append(limit)

    query = f"""
        SELECT
            u.id,
            u.url,
            u.title,
            v.visit_time
        FROM visits v
        JOIN urls u ON u.id = v.url
        WHERE {' AND '.join(where_clauses)}
        ORDER BY v.visit_time ASC
        LIMIT ?
    """

    cur.execute(query, params)
    rows = cur.fetchall()

    for row in rows:
        url_id = row["id"]
        url = row["url"] or ""
        title = row["title"] or ""
        visit_time = row["visit_time"]

        max_visit_time = max(max_visit_time, visit_time or 0)

        if not title.strip():
            continue

        try:
            if visit_time:
                unix_ts = (visit_time / 1_000_000) - 11644473600
                dt = datetime.fromtimestamp(unix_ts, tz=timezone.utc)
                timestamp_str = dt.isoformat()
                date_prefix = dt.strftime("%Y-%m-%d")
            else:
                timestamp_str = None
                date_prefix = "unknown"
        except Exception:
            timestamp_str = None
            date_prefix = "unknown"

        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc or "other"
        except Exception:
            domain = "other"

        content = f"{title}\n{url}"
        safe_domain = re.sub(r"[^\w\-_]", "_", domain)[:30]
        file_path = f"history/{safe_domain}/{date_prefix}_{url_id}.txt"

        files.append({
            "path": file_path,
            "content": content,
            "metadata": {
                "db_type": TYPE_CHROME_HISTORY,
                "row_id": url_id,
                "timestamp": timestamp_str,
                "url": url,
                "domain": domain,
            },
        })

    conn.close()
    logger.info(f"Extracted {len(files)} history items from Chrome")

    return {
        "files": files,
        "cursor": {"last_visit_time": max_visit_time},
        "stats": {"extracted": len(files), "db_type": TYPE_CHROME_HISTORY},
    }


def _extract_firefox_history(
    db_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract browsing history from Firefox places.sqlite."""
    files = []
    max_visit_date = cursor.get("last_visit_date", 0)
    since_visit_date = cursor.get("last_visit_date")

    conn = _connect_sqlite_readonly(db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    where_clauses = ["p.title IS NOT NULL", "p.title != ''"]
    params = []

    if since_visit_date:
        where_clauses.append("h.visit_date > ?")
        params.append(since_visit_date)

    params.append(limit)

    query = f"""
        SELECT
            p.id,
            p.url,
            p.title,
            h.visit_date
        FROM moz_places p
        JOIN moz_historyvisits h ON p.id = h.place_id
        WHERE {' AND '.join(where_clauses)}
        ORDER BY h.visit_date ASC
        LIMIT ?
    """

    cur.execute(query, params)
    rows = cur.fetchall()

    for row in rows:
        place_id = row["id"]
        url = row["url"] or ""
        title = row["title"] or ""
        visit_date = row["visit_date"]

        max_visit_date = max(max_visit_date, visit_date or 0)

        if not title.strip():
            continue

        try:
            if visit_date:
                unix_ts = visit_date / 1_000_000
                dt = datetime.fromtimestamp(unix_ts, tz=timezone.utc)
                timestamp_str = dt.isoformat()
                date_prefix = dt.strftime("%Y-%m-%d")
            else:
                timestamp_str = None
                date_prefix = "unknown"
        except Exception:
            timestamp_str = None
            date_prefix = "unknown"

        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc or "other"
        except Exception:
            domain = "other"

        content = f"{title}\n{url}"
        safe_domain = re.sub(r"[^\w\-_]", "_", domain)[:30]
        file_path = f"history/{safe_domain}/{date_prefix}_{place_id}.txt"

        files.append({
            "path": file_path,
            "content": content,
            "metadata": {
                "db_type": TYPE_FIREFOX_HISTORY,
                "row_id": place_id,
                "timestamp": timestamp_str,
                "url": url,
                "domain": domain,
            },
        })

    conn.close()
    logger.info(f"Extracted {len(files)} history items from Firefox")

    return {
        "files": files,
        "cursor": {"last_visit_date": max_visit_date},
        "stats": {"extracted": len(files), "db_type": TYPE_FIREFOX_HISTORY},
    }


def _extract_telegram(
    export_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract messages from Telegram export (JSON or ZIP)."""
    files = []
    max_message_id = cursor.get("last_message_id", 0)
    since_message_id = cursor.get("last_message_id")
    extracted_count = 0

    # Handle different input types
    if zipfile.is_zipfile(export_path):
        import tempfile
        with tempfile.TemporaryDirectory() as temp_dir:
            with zipfile.ZipFile(export_path, "r") as zf:
                zf.extractall(temp_dir)
            result_file = os.path.join(temp_dir, "result.json")
            if not os.path.exists(result_file):
                for item in os.listdir(temp_dir):
                    subdir = os.path.join(temp_dir, item)
                    if os.path.isdir(subdir):
                        candidate = os.path.join(subdir, "result.json")
                        if os.path.exists(candidate):
                            result_file = candidate
                            break
            return _extract_telegram_json(result_file, cursor, limit)
    elif os.path.isdir(export_path):
        result_file = os.path.join(export_path, "result.json")
    else:
        result_file = export_path

    return _extract_telegram_json(result_file, cursor, limit)


def _extract_telegram_json(
    result_file: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract from Telegram result.json file."""
    files = []
    max_message_id = cursor.get("last_message_id", 0)
    since_message_id = cursor.get("last_message_id")
    extracted_count = 0

    with open(result_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    chats_data = data.get("chats", {})
    chats = chats_data.get("list", []) if isinstance(chats_data, dict) else []

    for chat in chats:
        if extracted_count >= limit:
            break

        chat_name = chat.get("name", "Unknown Chat")
        chat_type = chat.get("type", "personal_chat")
        chat_id = chat.get("id", 0)

        messages = chat.get("messages", [])

        for msg in messages:
            if extracted_count >= limit:
                break

            msg_id = msg.get("id")
            msg_type = msg.get("type", "message")

            if since_message_id and msg_id and msg_id <= since_message_id:
                continue

            if msg_type != "message":
                continue

            # Handle text (can be string or list)
            text_content = msg.get("text", "")
            if isinstance(text_content, list):
                parts = []
                for item in text_content:
                    if isinstance(item, dict):
                        parts.append(item.get("text", ""))
                    elif isinstance(item, str):
                        parts.append(item)
                text_content = "".join(parts)

            if not text_content or not text_content.strip():
                continue

            if msg_id:
                max_message_id = max(max_message_id, msg_id)

            date_str = msg.get("date", "")
            try:
                if date_str:
                    dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                    timestamp_str = dt.isoformat()
                    date_prefix = dt.strftime("%Y-%m-%d")
                else:
                    timestamp_str = None
                    date_prefix = "unknown"
            except Exception:
                timestamp_str = date_str
                date_prefix = "unknown"

            from_name = msg.get("from", "") or msg.get("actor", "") or "Unknown"
            from_id = msg.get("from_id", "") or msg.get("actor_id", "")

            safe_chat = re.sub(r"[^\w\-_]", "_", chat_name)[:50]
            file_path = f"telegram/{safe_chat}/{date_prefix}_{msg_id}.txt"

            # Conversation-aware content
            conversation_id = str(chat_id) if chat_id else chat_name
            sender_role = "self" if from_name == "You" else "contact"

            time_display = ""
            try:
                if date_str:
                    dt_parsed = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                    time_display = dt_parsed.strftime("%H:%M")
            except Exception:
                pass

            if sender_role == "self":
                content = f"[You → {chat_name}, {date_prefix} {time_display}] {text_content}"
            else:
                content = f"[{from_name} → You, {date_prefix} {time_display}] {text_content}"

            files.append({
                "path": file_path,
                "content": content,
                "metadata": {
                    "db_type": TYPE_TELEGRAM,
                    "source_subtype": "telegram_export",
                    "chat_name": chat_name,
                    "chat_type": chat_type,
                    "chat_id": chat_id,
                    "conversation_id": conversation_id,
                    "sender_role": sender_role,
                    "contact": from_name,
                    "contact_id": str(from_id) if from_id else "",
                    "message_id": msg_id,
                    "timestamp": timestamp_str,
                    "from_name": from_name,
                },
            })
            extracted_count += 1

    # Group into conversation chunks
    raw_count = len(files)
    files = _group_messages_into_conversations(files)
    logger.info(f"Extracted {raw_count} messages from Telegram → {len(files)} conversation chunks")

    return {
        "files": files,
        "cursor": {"last_message_id": max_message_id},
        "stats": {"extracted": raw_count, "chunks": len(files), "db_type": TYPE_TELEGRAM},
    }


def _extract_folder(
    folder_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract text files from a regular folder with proper exclusion patterns."""
    files = []
    last_mtime = cursor.get("last_mtime", 0)
    last_path = cursor.get("last_path", "")
    max_mtime = last_mtime
    max_path = last_path
    extracted_count = 0
    custom_dirs, custom_files, custom_exts, custom_path_patterns = _get_custom_ignore_sets()
    skip_dirs = SKIP_DIRS | custom_dirs
    skip_files = SKIP_FILES | custom_files
    skip_exts = SKIP_EXTENSIONS | custom_exts
    skip_path_patterns = SKIP_PATH_PATTERNS | custom_path_patterns

    # Allowed text file extensions
    text_extensions = {
        ".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml",
        ".html", ".css", ".scss", ".less", ".xml", ".csv", ".sh", ".bash", ".zsh",
        ".rs", ".go", ".java", ".c", ".cpp", ".h", ".hpp", ".rb", ".vue", ".svelte",
        ".php", ".swift", ".kt", ".scala", ".r", ".sql", ".toml", ".ini", ".cfg",
        ".makefile", ".dockerfile", ".gitignore", ".editorconfig",
    }

    # Skip counters for logging
    skipped_counts: dict[str, int] = {
        "extension": 0,
        "no_extension": 0,
        "binary": 0,
        "too_large": 0,
        "security_pattern": 0,
        "filename_pattern": 0,
    }

    for root, dirs, filenames in os.walk(folder_path, topdown=True):
        if extracted_count >= limit:
            break

        # Filter out excluded directories IN-PLACE to prevent os.walk from descending
        dirs[:] = [
            d for d in dirs
            if d not in skip_dirs
            and not d.startswith(".")
            and not d.endswith(".egg-info")
        ]
        dirs.sort()
        filenames.sort()

        for filename in filenames:
            if extracted_count >= limit:
                break

            # Skip by filename
            if filename in skip_files:
                continue

            # Skip hidden files
            if filename.startswith("."):
                continue

            # Skip files matching security patterns (credentials, secrets, keys)
            filename_lower = filename.lower()
            if any(pattern in filename_lower for pattern in skip_path_patterns):
                skipped_counts["security_pattern"] += 1
                continue

            # Skip files matching known non-code filename patterns (GPG keys, etc.)
            if any(pattern in filename_lower for pattern in SKIP_FILENAME_PATTERNS):
                skipped_counts["filename_pattern"] += 1
                continue

            ext = Path(filename).suffix.lower()

            # Skip by extension
            if ext in skip_exts:
                skipped_counts["extension"] += 1
                continue

            # Only include known text extensions
            # Files without extension must be in the allowed extensionless list
            if not ext:
                if filename_lower not in ALLOWED_EXTENSIONLESS_FILES:
                    skipped_counts["no_extension"] += 1
                    continue
            elif ext not in text_extensions:
                skipped_counts["extension"] += 1
                continue

            file_path = os.path.join(root, filename)

            try:
                stat = os.stat(file_path)
                mtime = stat.st_mtime
                rel_path = os.path.relpath(file_path, folder_path)

                # Skip if not modified since last sync (tie-break by path)
                if mtime < last_mtime:
                    continue
                if mtime == last_mtime and rel_path <= last_path:
                    continue

                # Skip large files
                if stat.st_size > MAX_FILE_SIZE_BYTES:
                    skipped_counts["too_large"] += 1
                    logger.debug(f"Skipping oversized file: {file_path} ({stat.st_size} bytes)")
                    continue

                # Quick binary check on first 8KB before reading entire file
                with open(file_path, "rb") as fb:
                    sample = fb.read(8192)
                if _is_likely_binary(sample):
                    skipped_counts["binary"] += 1
                    logger.debug(f"Skipping binary file: {file_path}")
                    continue

                with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()

                if not content.strip():
                    continue

                files.append({
                    "path": rel_path,
                    "content": content,
                    "metadata": {
                        "db_type": TYPE_FOLDER,
                        "extension": ext,
                        "mtime": mtime,
                    },
                })
                extracted_count += 1
                if mtime > max_mtime or (mtime == max_mtime and rel_path > max_path):
                    max_mtime = mtime
                    max_path = rel_path

            except (PermissionError, IOError, OSError, UnicodeDecodeError) as e:
                logger.warning(f"Could not read {file_path}: {e}")
                continue

    total_skipped = sum(skipped_counts.values())
    logger.info(f"Extracted {len(files)} files from folder (skipped {total_skipped})")
    if total_skipped > 0:
        skip_details = ", ".join(f"{k}: {v}" for k, v in skipped_counts.items() if v > 0)
        logger.info(f"Skip breakdown: {skip_details}")

    return {
        "files": files,
        "cursor": {"last_mtime": max_mtime, "last_path": max_path},
        "stats": {"extracted": len(files), "db_type": TYPE_FOLDER, "skipped": total_skipped, "skip_details": {k: v for k, v in skipped_counts.items() if v > 0}},
    }


def _extract_generic_db(
    db_path: str,
    cursor: dict[str, Any],
    limit: int,
) -> dict[str, Any]:
    """Extract from generic SQLite database."""
    files = []
    total_extracted = 0

    skip_tables = {"sqlite_sequence", "sqlite_stat1", "sqlite_stat4"}

    conn = _connect_sqlite_readonly(db_path)
    cur = conn.cursor()

    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cur.fetchall()]

    for table_name in tables:
        if table_name.lower() in skip_tables:
            continue

        if total_extracted >= limit:
            break

        try:
            cur.execute(f'PRAGMA table_info("{table_name}")')
            columns = cur.fetchall()

            text_columns = [
                col[1]
                for col in columns
                if col[2].upper() in ("TEXT", "VARCHAR", "CHAR", "CLOB")
            ]

            if not text_columns:
                continue

            pk_column = next((col[1] for col in columns if col[5] == 1), "rowid")

            select_cols = [f'"{pk_column}"'] + [f'"{col}"' for col in text_columns]
            remaining = limit - total_extracted
            query = f'SELECT {", ".join(select_cols)} FROM "{table_name}" LIMIT ?'

            cur.execute(query, (remaining,))
            rows = cur.fetchall()

            for row in rows:
                pk_value = row[0]
                text_values = row[1:]

                combined = []
                for col_name, value in zip(text_columns, text_values):
                    if value and isinstance(value, str) and value.strip():
                        combined.append(f"{col_name}: {value}")

                if not combined:
                    continue

                content = "\n".join(combined)
                safe_table = re.sub(r"[^\w\-_]", "_", table_name)
                file_path = f"{safe_table}/row_{pk_value}.txt"

                files.append({
                    "path": file_path,
                    "content": content,
                    "metadata": {
                        "db_type": TYPE_GENERIC_DB,
                        "table": table_name,
                        "row_id": pk_value,
                    },
                })
                total_extracted += 1

        except Exception as e:
            logger.warning(f"Error extracting from table {table_name}: {e}")
            continue

    conn.close()
    logger.info(f"Extracted {len(files)} rows from generic database")

    return {
        "files": files,
        "cursor": {},
        "stats": {"extracted": len(files), "db_type": TYPE_GENERIC_DB},
    }
